<template>
  <el-dialog
    :title="!dataForm.stuId ? '新增' : '修改'"
    :close-on-click-modal="false"
    :visible.sync="visible">
    <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()" label-width="80px">
    <el-form-item label="姓名" prop="name">
      <el-input v-model="dataForm.name" placeholder="姓名"></el-input>
    </el-form-item>
    <el-form-item label="学号" prop="stuNum">
      <el-input v-model="dataForm.stuNum" placeholder="学号"></el-input>
    </el-form-item>
    <el-form-item label="微信号" prop="wxNum">
      <el-input v-model="dataForm.wxNum" placeholder="微信号"></el-input>
    </el-form-item>
    <el-form-item label="地址" prop="address">
      <el-input v-model="dataForm.address" placeholder="地址"></el-input>
    </el-form-item>
    <el-form-item label="年级" prop="grade">
      <el-input v-model="dataForm.grade" placeholder="年级"></el-input>
    </el-form-item>
    <el-form-item label="班级" prop="clazz">
      <el-input v-model="dataForm.clazz" placeholder="班级"></el-input>
    </el-form-item>
      <el-form-item label="联系人" prop="clazz">
        <el-input v-model="dataForm.linkman" placeholder="联系电话"></el-input>
      </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" @click="dataFormSubmit()">确定</el-button>
    </span>
  </el-dialog>
</template>

<script>
  export default {
    data () {
      return {
        visible: false,
        dataForm: {
          stuId: 0,
          name: '',
          stuNum: '',
          wxNum: '',
          address: '',
          grade: '',
          clazz: '',
          linkman: ''
        },
        dataRule: {
          name: [
            { required: true, message: '不能为空', trigger: 'blur' }
          ],
          stuNum: [
            { required: true, message: '不能为空', trigger: 'blur' }
          ],
          wxNum: [
            { required: true, message: '不能为空', trigger: 'blur' }
          ],
          address: [
            { required: true, message: '不能为空', trigger: 'blur' }
          ],
          grade: [
            { required: true, message: '不能为空', trigger: 'blur' }
          ],
          clazz: [
            { required: true, message: '不能为空', trigger: 'blur' }
          ],
          linkman: [
            { required: true, message: '不能为空', trigger: 'blur' }
          ]
        }
      }
    },
    methods: {
      init (id) {
        this.dataForm.stuId = id || 0
        this.visible = true
        this.$nextTick(() => {
          this.$refs['dataForm'].resetFields()
          if (this.dataForm.stuId) {
            this.$http({
              url: this.$http.adornUrl(`/student/tstutudent/info/${this.dataForm.stuId}`),
              method: 'get',
              params: this.$http.adornParams()
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.dataForm.name = data.tStutudent.name
                this.dataForm.stuNum = data.tStutudent.stuNum
                this.dataForm.wxNum = data.tStutudent.wxNum
                this.dataForm.address = data.tStutudent.address
                this.dataForm.grade = data.tStutudent.grade
                this.dataForm.clazz = data.tStutudent.clazz
                this.dataForm.linkman = data.tStutudent.linkman
              }
            })
          }
        })
      },
      // 表单提交
      dataFormSubmit () {
        this.$refs['dataForm'].validate((valid) => {
          if (valid) {
            this.$http({
              url: this.$http.adornUrl(`/student/tstutudent/${!this.dataForm.stuId ? 'save' : 'update'}`),
              method: 'post',
              data: this.$http.adornData({
                'stuId': this.dataForm.stuId || undefined,
                'name': this.dataForm.name,
                'stuNum': this.dataForm.stuNum,
                'wxNum': this.dataForm.wxNum,
                'address': this.dataForm.address,
                'grade': this.dataForm.grade,
                'clazz': this.dataForm.clazz,
                'linkman': this.dataForm.linkman
              })
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.$message({
                  message: '操作成功',
                  type: 'success',
                  duration: 1500,
                  onClose: () => {
                    this.visible = false
                    this.$emit('refreshDataList')
                  }
                })
              } else {
                this.$message.error(data.msg)
              }
            })
          }
        })
      }
    }
  }
</script>
